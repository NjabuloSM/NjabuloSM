import joblib
import numpy as np

# Load the trained model and scaler
model = joblib.load('best_model.pkl')
scaler = joblib.load('scaler.pkl')

def classify(X):
    # Apply the same preprocessing
    X_scaled = scaler.transform(X)
    # Predict using the loaded model
    return model.predict(X_scaled)

if __name__ == "__main__":
    print("Loading test data...")
    test_data = np.loadtxt('testdata.txt', delimiter=',')
    print(f"Test data shape: {test_data.shape}")
    pred_labels = classify(test_data)
    print(f"Predictions: {pred_labels}")
    np.savetxt('predlabels.txt', pred_labels, fmt='%d')
    print("Predictions saved to 'predlabels.txt'")

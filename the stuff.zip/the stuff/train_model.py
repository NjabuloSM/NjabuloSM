import numpy as np
from sklearn.model_selection import train_test_split, RandomizedSearchCV
from sklearn.ensemble import RandomForestClassifier
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import Pipeline
from sklearn.metrics import accuracy_score
import joblib
from scipy.stats import randint
import time

# Start timing
start_time = time.time()

# Load dataset with comma delimiter
X = np.loadtxt('traindata.txt', delimiter=',')
y = np.loadtxt('trainlabels.txt', delimiter=',')

# Use a smaller subset of the data for quick testing
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.1, random_state=42)

# Preprocessing and model pipeline
scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)

model = RandomForestClassifier(random_state=42)

# Hyperparameters for tuning
param_dist = {
    'n_estimators': randint(50, 100),
    'max_features': ['sqrt', 'log2'],
    'max_depth': [None, 10],
    'min_samples_split': randint(2, 5),
    'min_samples_leaf': randint(1, 2)
}

# Randomized search for hyperparameter tuning
random_search = RandomizedSearchCV(model, param_dist, n_iter=10, cv=3, n_jobs=-1, verbose=1, random_state=42)
random_search.fit(X_train_scaled, y_train)

# Save the best model and the scaler
joblib.dump(random_search.best_estimator_, 'best_model.pkl')
joblib.dump(scaler, 'scaler.pkl')
print("Model and scaler saved as 'best_model.pkl' and 'scaler.pkl'")

# Make predictions
y_pred = random_search.predict(X_test_scaled)

# Calculate accuracy
accuracy = accuracy_score(y_test, y_pred)
print(f'Best Model: {random_search.best_estimator_}')
print(f'Accuracy: {accuracy * 100:.2f}%')

# End timing
end_time = time.time()
print(f'Training time: {end_time - start_time:.2f} seconds')

import numpy as np
from classifyall import classify

def main():
    eval_data_name = 'testdata.txt'
    eval_labels_name = 'targetlabels.txt'
    pred_labels_name = 'predlabels.txt'

    try:
        # Load test data and labels
        print("Loading test data and labels...")
        test_data = np.loadtxt(eval_data_name, delimiter=',')
        test_labels = np.loadtxt(eval_labels_name, delimiter=',')
        print(f"Test data shape: {test_data.shape}")
        print(f"Test labels shape: {test_labels.shape}")

        # Predict using the classify function
        pred_labels = classify(test_data)

        # Save predictions to file
        np.savetxt(pred_labels_name, pred_labels, fmt='%d')

        # Calculate accuracy
        n_correct = 0
        n_labels = len(test_labels)
        for curr_pred_label, curr_test_label in zip(pred_labels, test_labels):
            if int(curr_pred_label) == int(curr_test_label):
                n_correct += 1
        print("Accuracy:", (n_correct/n_labels)*100)

    except FileNotFoundError as e:
        raise FileNotFoundError(e)
    except Exception as e:
        raise RuntimeError(e)

if __name__ == "__main__":
    main()
